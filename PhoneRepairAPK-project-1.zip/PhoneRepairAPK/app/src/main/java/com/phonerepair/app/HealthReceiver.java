package com.phonerepair.app;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Environment;
import android.os.StatFs;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;

/** تنبيهات حالة الهاتف: فحص يومي خفيف + تنبيه فوري بعد الفحص إذا وُجدت أعطال. */
public class HealthReceiver extends BroadcastReceiver {
    static final String ACTION_CHECK = "com.phonerepair.app.HEALTH_CHECK";
    static final String CH = "health";
    static final String SHOP = "محل السالك، المرصة الشرقية، السمارة";
    static final long THREE_DAYS = 3L * 24 * 3600 * 1000;
    static final long MONTH = 30L * 24 * 3600 * 1000;

    @Override
    public void onReceive(Context ctx, Intent intent) {
        String a = intent == null ? null : intent.getAction();
        if (!enabled(ctx)) return;
        if (Intent.ACTION_BOOT_COMPLETED.equals(a)) {
            schedule(ctx);
        } else if (ACTION_CHECK.equals(a)) {
            check(ctx);
        }
    }

    static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences("health", Context.MODE_PRIVATE);
    }

    static boolean enabled(Context c) {
        return prefs(c).getBoolean("enabled", false);
    }

    static void setEnabled(Context c, boolean on) {
        prefs(c).edit().putBoolean("enabled", on).apply();
        if (on) schedule(c);
        else cancel(c);
    }

    static boolean allowed(Context c) {
        try {
            if (Build.VERSION.SDK_INT >= 33
                    && c.checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED)
                return false;
            NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
            return nm.areNotificationsEnabled();
        } catch (Throwable t) {
            return false;
        }
    }

    private static int flags() {
        return Build.VERSION.SDK_INT >= 23
                ? PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
                : PendingIntent.FLAG_UPDATE_CURRENT;
    }

    private static PendingIntent alarmIntent(Context c) {
        Intent i = new Intent(c, HealthReceiver.class);
        i.setAction(ACTION_CHECK);
        return PendingIntent.getBroadcast(c, 10, i, flags());
    }

    static void schedule(Context c) {
        try {
            AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
            am.setInexactRepeating(AlarmManager.RTC, System.currentTimeMillis() + 6L * 3600 * 1000,
                    AlarmManager.INTERVAL_DAY, alarmIntent(c));
        } catch (Throwable ignored) {
        }
    }

    static void cancel(Context c) {
        try {
            ((AlarmManager) c.getSystemService(Context.ALARM_SERVICE)).cancel(alarmIntent(c));
        } catch (Throwable ignored) {
        }
    }

    private static long readLong(String path) {
        try {
            BufferedReader r = new BufferedReader(new FileReader(path));
            String s = r.readLine();
            r.close();
            return s == null ? -1 : Long.parseLong(s.trim());
        } catch (Throwable t) {
            return -1;
        }
    }

    /** فحص يومي خفيف دون واجهة: حرارة وحالة البطارية، امتلاء التخزين، عمر البطارية، قدم آخر فحص. */
    static void check(Context c) {
        SharedPreferences p = prefs(c);
        long now = System.currentTimeMillis();
        if (now - p.getLong("last_notif", 0) < THREE_DAYS) return;
        List<String> issues = new ArrayList<String>();
        try {
            Intent b = c.getApplicationContext().registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
            if (b != null) {
                int health = b.getIntExtra(BatteryManager.EXTRA_HEALTH, 2);
                if (health == BatteryManager.BATTERY_HEALTH_OVERHEAT || health == BatteryManager.BATTERY_HEALTH_DEAD
                        || health == BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE || health == BatteryManager.BATTERY_HEALTH_UNSPECIFIED_FAILURE)
                    issues.add("حالة البطارية غير جيدة");
                int temp = b.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0);
                if (temp >= 450) issues.add("حرارة البطارية مرتفعة (" + (temp / 10) + "°م)");
            }
        } catch (Throwable ignored) {
        }
        try {
            StatFs fs = new StatFs(Environment.getDataDirectory().getPath());
            double free = fs.getAvailableBytes() * 100.0 / fs.getTotalBytes();
            if (free < 10) issues.add("التخزين شبه ممتلئ (المتاح " + Math.round(free) + "%)");
        } catch (Throwable ignored) {
        }
        try {
            long full = readLong("/sys/class/power_supply/battery/charge_full");
            long des = readLong("/sys/class/power_supply/battery/charge_full_design");
            int pct = -1;
            if (Build.VERSION.SDK_INT >= 34) {
                BatteryManager bm = (BatteryManager) c.getSystemService(Context.BATTERY_SERVICE);
                int soh = bm.getIntProperty(10);
                if (soh > 0 && soh <= 100) pct = soh;
            }
            if (pct < 0 && full > 0 && des > 0) pct = (int) Math.round(full * 100.0 / des);
            if (pct > 30 && pct < 80) issues.add("عمر البطارية تراجع إلى نحو " + Math.min(100, pct) + "%");
        } catch (Throwable ignored) {
        }
        int last = p.getInt("last_issues", 0);
        long lastScan = p.getLong("last_scan", 0);
        if (last > 0) issues.add("الفحص الأخير اكتشف " + last + " ملاحظة لم تُعالج");
        if (lastScan == 0 || now - lastScan > MONTH) issues.add("لم تُجرِ فحصاً لهاتفك منذ أكثر من شهر");
        if (issues.isEmpty()) return;
        StringBuilder sb = new StringBuilder();
        for (String s : issues) sb.append("• ").append(s).append("\n");
        sb.append("افتح التطبيق وأجرِ الفحص، ثم توجّه إلى ").append(SHOP).append(" لتلقي الدعم وإصلاح الأعطال.");
        if (post(c, "هاتفك يحتاج فحصاً", sb.toString())) p.edit().putLong("last_notif", now).apply();
    }

    /** أيقونة التطبيق لتظهر داخل الإشعار (الأيقونة الصغيرة في شريط الحالة يفرض النظام أن تكون أحادية اللون). */
    private static Bitmap appIcon(Context c) {
        try {
            return BitmapFactory.decodeResource(c.getResources(), R.mipmap.ic_launcher);
        } catch (Throwable t) {
            return null;
        }
    }

    static boolean post(Context c, String title, String body) {
        try {
            if (!allowed(c)) return false;
            NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
            Notification.Builder nb;
            if (Build.VERSION.SDK_INT >= 26) {
                nm.createNotificationChannel(new NotificationChannel(CH, "حالة الهاتف", NotificationManager.IMPORTANCE_DEFAULT));
                nb = new Notification.Builder(c, CH);
            } else {
                nb = new Notification.Builder(c);
                nb.setPriority(Notification.PRIORITY_DEFAULT);
            }
            Intent open = new Intent(c, MainActivity.class);
            open.setAction(Intent.ACTION_MAIN);
            open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            open.putExtra("open", "scan");
            String first = body.indexOf('\n') > 0 ? body.substring(0, body.indexOf('\n')) : body;
            nb.setSmallIcon(R.drawable.ic_stat)
                    .setLargeIcon(appIcon(c))
                    .setContentTitle(title)
                    .setContentText(first.replace("• ", ""))
                    .setStyle(new Notification.BigTextStyle().bigText(body))
                    .setAutoCancel(true)
                    .setContentIntent(PendingIntent.getActivity(c, 11, open, flags()));
            nm.notify(1001, nb.build());
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    /** تنبيه فوري بعد انتهاء الفحص داخل التطبيق. */
    static void afterScan(Context c, int bad, int warn, String names) {
        SharedPreferences p = prefs(c);
        p.edit().putLong("last_scan", System.currentTimeMillis()).putInt("last_issues", bad + warn).apply();
        if (!enabled(c) || bad + warn == 0) return;
        String body = (bad > 0 ? bad + " عطل يحتاج إصلاحاً" : "") + (bad > 0 && warn > 0 ? " و " : "")
                + (warn > 0 ? warn + " ملاحظة تحتاج متابعة" : "") + "."
                + (names != null && names.length() > 0 ? "\n• " + names : "")
                + "\nتوجّه إلى " + SHOP + " لتلقي الدعم وإصلاح الأعطال المكتشفة.";
        if (post(c, "اكتُشفت أعطال في هاتفك", body)) p.edit().putLong("last_notif", System.currentTimeMillis()).apply();
    }
}
