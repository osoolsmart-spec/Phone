package com.phonerepair.app;

import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.BatteryManager;
import android.os.Environment;
import android.os.StatFs;
import android.widget.RemoteViews;

import java.util.Locale;

/** لقطة سريعة من حالة الهاتف (الذاكرة، التخزين، البطارية) تُعرض في الويدجت والإشعارات. */
final class Stats {
    private static final String LTR = "\u200E";

    int ramPct, stoPct, batPct;
    long ramUsed, ramTotal, stoUsed, stoTotal;
    float volt = -1, temp = -1;
    boolean charging;

    static Stats read(Context c) {
        Stats s = new Stats();
        try {
            ActivityManager am = (ActivityManager) c.getSystemService(Context.ACTIVITY_SERVICE);
            ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
            am.getMemoryInfo(mi);
            s.ramTotal = mi.totalMem;
            s.ramUsed = mi.totalMem - mi.availMem;
            if (s.ramTotal > 0) s.ramPct = Math.round(s.ramUsed * 100f / s.ramTotal);
        } catch (Throwable ignored) {
        }
        try {
            StatFs fs = new StatFs(Environment.getDataDirectory().getPath());
            s.stoTotal = fs.getTotalBytes();
            s.stoUsed = s.stoTotal - fs.getAvailableBytes();
            if (s.stoTotal > 0) s.stoPct = Math.round(s.stoUsed * 100f / s.stoTotal);
        } catch (Throwable ignored) {
        }
        try {
            Intent b = c.getApplicationContext().registerReceiver(null,
                    new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
            if (b != null) {
                int lv = b.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
                int sc = b.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
                if (lv >= 0 && sc > 0) s.batPct = Math.round(lv * 100f / sc);
                int mv = b.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0);
                if (mv > 0) s.volt = mv / 1000f;
                int t = b.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Integer.MIN_VALUE);
                if (t != Integer.MIN_VALUE) s.temp = t / 10f;
                int st = b.getIntExtra(BatteryManager.EXTRA_STATUS, 1);
                s.charging = st == BatteryManager.BATTERY_STATUS_CHARGING
                        || st == BatteryManager.BATTERY_STATUS_FULL;
            }
        } catch (Throwable ignored) {
        }
        return s;
    }

    private static String gb(long bytes) {
        return String.format(Locale.US, "%.2fG", bytes / 1073741824.0);
    }

    /** يملأ العناصر المشتركة في stats_block.xml. */
    void fill(RemoteViews rv) {
        rv.setProgressBar(R.id.r_ring, 100, ramPct, false);
        rv.setTextViewText(R.id.r_ram_pct, ramPct + "%");
        rv.setTextViewText(R.id.r_ram_txt, LTR + gb(ramUsed) + "/" + gb(ramTotal));

        rv.setProgressBar(R.id.r_sto_bar, 100, stoPct, false);
        rv.setTextViewText(R.id.r_sto_txt, LTR + gb(stoUsed) + " / " + gb(stoTotal));
        rv.setTextViewText(R.id.r_sto_pct, stoPct + "%");

        rv.setProgressBar(R.id.r_bat_bar, 100, batPct, false);
        String bt = "";
        if (volt > 0) bt += String.format(Locale.US, "%.2f V", volt);
        if (temp > -100) bt += (bt.length() > 0 ? " / " : "") + String.format(Locale.US, "%.1f\u2103", temp);
        rv.setTextViewText(R.id.r_bat_txt, LTR + bt);
        rv.setTextViewText(R.id.r_bat_pct, batPct + "%");
        rv.setTextViewText(R.id.r_bat_lbl, charging ? "البطارية ⚡" : "البطارية");
    }
}
