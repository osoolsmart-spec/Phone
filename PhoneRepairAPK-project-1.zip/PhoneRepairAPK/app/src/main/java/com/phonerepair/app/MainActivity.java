package com.phonerepair.app;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {
    private WebView web;
    private DeviceBridge bridge;
    private boolean loaded = false;
    private String pending = null;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        web = new WebView(this);
        setContentView(web);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        bridge = new DeviceBridge(this, web);
        web.addJavascriptInterface(bridge, "Android");
        pending = b == null ? getIntent().getStringExtra("open") : null;
        web.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView v, String url) {
                loaded = true;
                runPending();
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                if ("file".equals(u.getScheme())) return false;
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, u));
                } catch (Exception ignored) {
                }
                return true;
            }
        });
        if (b == null) web.loadUrl("file:///android_asset/index.html");
        else web.restoreState(b);
    }

    private void runPending() {
        if (!loaded || pending == null || pending.length() == 0) {
            pending = null;
            return;
        }
        final String w = pending;
        pending = null;
        web.postDelayed(new Runnable() {
            public void run() {
                web.evaluateJavascript("window.openFromWidget&&openFromWidget('" + w.replaceAll("[^a-z]", "") + "')", null);
            }
        }, 300);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == 7710) {
            String r = "";
            if (res == RESULT_OK && data != null) {
                String n = data.getStringExtra(android.accounts.AccountManager.KEY_ACCOUNT_NAME);
                if (n != null && n.length() > 0) {
                    int at = n.indexOf('@');
                    r = at > 1 ? n.substring(0, 1) + "***" + n.substring(at) : "***";
                }
            }
            final String out = r.replace("'", "");
            web.evaluateJavascript("window.onGoogleAccount&&onGoogleAccount('" + out + "')", null);
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        pending = intent.getStringExtra("open");
        runPending();
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] results) {
        super.onRequestPermissionsResult(code, perms, results);
        if (code == DeviceBridge.REQ) bridge.onPermResult();
    }

    @Override
    protected void onSaveInstanceState(Bundle o) {
        super.onSaveInstanceState(o);
        web.saveState(o);
    }

    @Override
    public void onBackPressed() {
        if (web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }
}
