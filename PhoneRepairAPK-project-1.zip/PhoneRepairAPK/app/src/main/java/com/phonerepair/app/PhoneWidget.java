package com.phonerepair.app;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.BatteryManager;
import android.os.Build;
import android.widget.RemoteViews;

/** ويدجت الشاشة الرئيسية: زر فحص الهاتف وزر فحص الشاحن مع مستوى البطارية. */
public class PhoneWidget extends AppWidgetProvider {
    static final String REFRESH = "com.phonerepair.app.REFRESH";

    @Override
    public void onUpdate(Context ctx, AppWidgetManager mgr, int[] ids) {
        for (int id : ids) mgr.updateAppWidget(id, build(ctx));
    }

    @Override
    public void onReceive(Context ctx, Intent intent) {
        super.onReceive(ctx, intent);
        if (REFRESH.equals(intent.getAction())) {
            AppWidgetManager m = AppWidgetManager.getInstance(ctx);
            int[] ids = m.getAppWidgetIds(new ComponentName(ctx, PhoneWidget.class));
            onUpdate(ctx, m, ids);
        }
    }

    private static PendingIntent open(Context ctx, String what, int code) {
        Intent i = new Intent(ctx, MainActivity.class);
        i.setAction(Intent.ACTION_MAIN);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        i.putExtra("open", what);
        return PendingIntent.getActivity(ctx, code, i, flags());
    }

    private static int flags() {
        return Build.VERSION.SDK_INT >= 23
                ? PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
                : PendingIntent.FLAG_UPDATE_CURRENT;
    }

    private static RemoteViews build(Context ctx) {
        RemoteViews rv = new RemoteViews(ctx.getPackageName(), R.layout.widget);
        String batt = "اضغط لتحديث حالة البطارية";
        try {
            Intent b = ctx.getApplicationContext().registerReceiver(null,
                    new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
            if (b != null) {
                int lv = b.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
                int sc = b.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
                int st = b.getIntExtra(BatteryManager.EXTRA_STATUS, 1);
                int pct = (lv >= 0 && sc > 0) ? Math.round(lv * 100f / sc) : -1;
                boolean ch = st == BatteryManager.BATTERY_STATUS_CHARGING
                        || st == BatteryManager.BATTERY_STATUS_FULL;
                if (pct >= 0) batt = "البطارية " + pct + "% · " + (ch ? "قيد الشحن" : "غير موصول بالشاحن");
            }
        } catch (Throwable ignored) {
        }
        rv.setTextViewText(R.id.w_batt, batt);
        rv.setOnClickPendingIntent(R.id.w_scan, open(ctx, "scan", 1));
        rv.setOnClickPendingIntent(R.id.w_chg, open(ctx, "charger", 2));
        rv.setOnClickPendingIntent(R.id.w_title, open(ctx, "", 3));
        Intent r = new Intent(ctx, PhoneWidget.class);
        r.setAction(REFRESH);
        rv.setOnClickPendingIntent(R.id.w_batt, PendingIntent.getBroadcast(ctx, 4, r, flags()));
        return rv;
    }
}
