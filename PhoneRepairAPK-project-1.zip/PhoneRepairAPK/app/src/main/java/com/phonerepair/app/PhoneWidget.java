package com.phonerepair.app;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.widget.RemoteViews;

/** ويدجت الشاشة الرئيسية: مؤشرات الذاكرة والتخزين والبطارية مع زرّي فحص الهاتف والشاحن. */
public class PhoneWidget extends AppWidgetProvider {
    static final String REFRESH = "com.phonerepair.app.REFRESH";

    @Override
    public void onUpdate(Context ctx, AppWidgetManager mgr, int[] ids) {
        for (int id : ids) mgr.updateAppWidget(id, build(ctx));
    }

    @Override
    public void onReceive(Context ctx, Intent intent) {
        super.onReceive(ctx, intent);
        if (REFRESH.equals(intent.getAction())) {
            AppWidgetManager m = AppWidgetManager.getInstance(ctx);
            int[] ids = m.getAppWidgetIds(new ComponentName(ctx, PhoneWidget.class));
            onUpdate(ctx, m, ids);
        }
    }

    private static PendingIntent open(Context ctx, String what, int code) {
        Intent i = new Intent(ctx, MainActivity.class);
        i.setAction(Intent.ACTION_MAIN);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        i.putExtra("open", what);
        return PendingIntent.getActivity(ctx, code, i, flags());
    }

    private static int flags() {
        return Build.VERSION.SDK_INT >= 23
                ? PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
                : PendingIntent.FLAG_UPDATE_CURRENT;
    }

    private static RemoteViews build(Context ctx) {
        RemoteViews rv = new RemoteViews(ctx.getPackageName(), R.layout.widget);
        Stats.read(ctx).fill(rv);
        // ألوان فاتحة للنصوص لأن خلفية الويدجت داكنة دائماً
        int[] muted = {R.id.r_ram_txt, R.id.r_ram_lbl, R.id.r_sto_lbl, R.id.r_sto_txt,
                R.id.r_bat_lbl, R.id.r_bat_txt};
        for (int id : muted) rv.setTextColor(id, 0xFF8E8E8E);
        int[] strong = {R.id.r_ram_pct, R.id.r_sto_pct, R.id.r_bat_pct};
        for (int id : strong) rv.setTextColor(id, 0xFFD6D6D6);
        rv.setOnClickPendingIntent(R.id.w_scan, open(ctx, "scan", 1));
        rv.setOnClickPendingIntent(R.id.w_chg, open(ctx, "charger", 2));
        rv.setOnClickPendingIntent(R.id.w_title, open(ctx, "", 3));
        Intent r = new Intent(ctx, PhoneWidget.class);
        r.setAction(REFRESH);
        PendingIntent refresh = PendingIntent.getBroadcast(ctx, 4, r, flags());
        rv.setOnClickPendingIntent(R.id.w_refresh, refresh);
        rv.setOnClickPendingIntent(R.id.r_stats, refresh);
        return rv;
    }
}
