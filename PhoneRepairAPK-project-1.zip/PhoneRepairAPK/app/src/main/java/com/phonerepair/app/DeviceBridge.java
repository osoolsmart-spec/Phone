package com.phonerepair.app;

import android.Manifest;
import android.app.ActivityManager;
import android.app.AppOpsManager;
import android.app.KeyguardManager;
import android.app.admin.DevicePolicyManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.media.AudioFormat;
import android.media.MediaDrm;
import android.media.AudioManager;
import android.media.AudioRecord;
import android.media.MediaRecorder;
import android.media.ToneGenerator;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.Uri;
import android.net.wifi.WifiManager;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.StatFs;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.provider.Settings;
import android.telephony.TelephonyManager;
import android.util.DisplayMetrics;
import android.view.Display;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintManager;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.UUID;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

/** جسر بين صفحة التطبيق (JavaScript) وبيانات الهاتف الحقيقية. يُستدعى باسم Android من الصفحة. */
public class DeviceBridge {
    static final int REQ = 77;
    private final MainActivity act;
    private final WebView web;
    private final Handler main = new Handler(Looper.getMainLooper());

    DeviceBridge(MainActivity a, WebView w) {
        act = a;
        web = w;
    }

    private static void put(JSONObject o, String k, Object v) {
        try {
            o.put(k, v);
        } catch (JSONException ignored) {
        }
    }

    // ===================== طباعة / حفظ التقرير كملف PDF =====================
    private WebView printWeb;

    @JavascriptInterface
    public void printReport(final String html, final String title) {
        act.runOnUiThread(new Runnable() {
            public void run() {
                try {
                    final boolean[] done = {false};
                    final String name = (title == null || title.length() == 0) ? "Phone-Report" : title;
                    WebView w = new WebView(act);
                    w.setWebViewClient(new WebViewClient() {
                        @Override
                        public void onPageFinished(WebView v, String url) {
                            if (done[0]) return;
                            done[0] = true;
                            PrintManager pm = (PrintManager) act.getSystemService(Context.PRINT_SERVICE);
                            PrintDocumentAdapter ad = v.createPrintDocumentAdapter(name);
                            pm.print(name, ad, new PrintAttributes.Builder()
                                    .setMediaSize(PrintAttributes.MediaSize.ISO_A4).build());
                        }
                    });
                    printWeb = w; // نحتفظ بها حتى لا تُحذف قبل انتهاء الطباعة
                    w.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null);
                } catch (Throwable ignored) {
                }
            }
        });
    }

    // ===================== واتساب =====================
    private JSONObject waState(String pkg, String accType) {
        JSONObject o = pkgState(pkg);
        try {
            if (o.optBoolean("installed")) {
                PackageManager pm = act.getPackageManager();
                int fl = pm.getApplicationInfo(pkg, 0).flags;
                put(o, "stopped", (fl & 0x200000) != 0); // FLAG_STOPPED
                put(o, "launchable", pm.getLaunchIntentForPackage(pkg) != null);
                JSONArray names = new JSONArray();
                try {
                    for (android.accounts.Account a : android.accounts.AccountManager.get(act).getAccountsByType(accType))
                        names.put(a.name);
                } catch (Throwable ignored) {
                }
                put(o, "accounts", names);
            }
        } catch (Throwable ignored) {
        }
        return o;
    }

    private JSONObject waInfo() {
        JSONObject o = new JSONObject();
        put(o, "wa", waState("com.whatsapp", "com.whatsapp"));
        put(o, "biz", waState("com.whatsapp.w4b", "com.whatsapp.w4b"));
        return o;
    }

    @JavascriptInterface
    public void launchApp(final String pkg) {
        act.runOnUiThread(new Runnable() {
            public void run() {
                try {
                    Intent in = act.getPackageManager().getLaunchIntentForPackage(pkg);
                    if (in != null && pkg.startsWith("com.whatsapp")) act.startActivity(in);
                } catch (Throwable ignored) {
                }
            }
        });
    }

    // ===================== التنبيهات =====================
    static final int REQ_NOTIF = 7711;

    @JavascriptInterface
    public String notifState() {
        JSONObject o = new JSONObject();
        put(o, "enabled", HealthReceiver.enabled(act));
        put(o, "allowed", HealthReceiver.allowed(act));
        return o.toString();
    }

    @JavascriptInterface
    public void notifEnable(final boolean on) {
        act.runOnUiThread(new Runnable() {
            public void run() {
                if (!on) {
                    HealthReceiver.setEnabled(act, false);
                    return;
                }
                if (Build.VERSION.SDK_INT >= 33
                        && act.checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) {
                    act.requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, REQ_NOTIF);
                } else {
                    HealthReceiver.setEnabled(act, true);
                }
            }
        });
    }

    @JavascriptInterface
    public void reportScan(int bad, int warn, String names) {
        HealthReceiver.afterScan(act, bad, warn, names);
    }

    // ===================== حساب قوقل + متجر Play + خدمات Google Play =====================
    private JSONObject pkgState(String pkg) {
        JSONObject o = new JSONObject();
        try {
            PackageManager pm = act.getPackageManager();
            android.content.pm.PackageInfo pi = pm.getPackageInfo(pkg, 0);
            put(o, "installed", true);
            String vn = pi.versionName == null ? "" : pi.versionName.trim();
            int sp = vn.indexOf(' ');
            put(o, "version", sp > 0 ? vn.substring(0, sp) : vn);
            put(o, "code", Build.VERSION.SDK_INT >= 28 ? pi.getLongVersionCode() : pi.versionCode);
            put(o, "days", (System.currentTimeMillis() - pi.lastUpdateTime) / 86400000L);
            put(o, "enabled", pm.getApplicationInfo(pkg, 0).enabled);
        } catch (Throwable t) {
            put(o, "installed", false);
        }
        return o;
    }

    private JSONObject googleInfo() {
        JSONObject o = new JSONObject();
        try {
            put(o, "play", pkgState("com.android.vending"));
            put(o, "gms", pkgState("com.google.android.gms"));
            try {
                android.accounts.Account[] acc = android.accounts.AccountManager.get(act).getAccountsByType("com.google");
                put(o, "accounts", acc.length);
            } catch (Throwable t) {
                put(o, "accounts", -1);
            }
        } catch (Throwable ignored) {
        }
        return o;
    }

    /** يفتح نافذة النظام لاختيار حساب قوقل؛ لا نحفظ البريد ولا نرسله، فقط نعرف أن الحساب موجود. */
    @JavascriptInterface
    public void googleAccountCheck() {
        act.runOnUiThread(new Runnable() {
            @SuppressWarnings("deprecation")
            public void run() {
                try {
                    Intent in;
                    if (Build.VERSION.SDK_INT >= 26) {
                        in = android.accounts.AccountManager.newChooseAccountIntent(null, null,
                                new String[]{"com.google"}, null, null, null, null);
                    } else {
                        in = android.accounts.AccountManager.newChooseAccountIntent(null, null,
                                new String[]{"com.google"}, false, null, null, null, null);
                    }
                    act.startActivityForResult(in, 7710);
                } catch (Throwable t) {
                    act.runOnUiThread(new Runnable() {
                        public void run() {
                        }
                    });
                }
            }
        });
    }

    // ===================== فحص الشاحن (قراءة لحظية) =====================
    @JavascriptInterface
    public String charger() {
        JSONObject o = new JSONObject();
        try {
            Intent i = act.registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
            if (i == null) return o.toString();
            int lv = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
            int sc = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
            put(o, "level", (lv >= 0 && sc > 0) ? Math.round(lv * 100f / sc) : -1);
            int plugged = i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0);
            put(o, "plugged", plugged);
            int status = i.getIntExtra(BatteryManager.EXTRA_STATUS, 1);
            put(o, "status", status);
            put(o, "voltageMv", i.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0));
            put(o, "temp", i.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) / 10.0);

            BatteryManager bm = (BatteryManager) act.getSystemService(Context.BATTERY_SERVICE);
            int cur = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW);
            if (cur != Integer.MIN_VALUE && cur != 0) {
                long a = Math.abs((long) cur);
                put(o, "currentMa", a >= 20000 ? a / 1000 : a); // بعض الأجهزة تعطيها بالمللي أمبير مباشرة
            }
            long cc = bm.getLongProperty(BatteryManager.BATTERY_PROPERTY_CHARGE_COUNTER);
            if (cc > 0 && cc != Long.MIN_VALUE) put(o, "remainMah", Math.round(cc / 1000.0));
            if (Build.VERSION.SDK_INT >= 28) {
                long t = bm.computeChargeTimeRemaining();
                if (t > 0) put(o, "fullInMs", t);
            }
            long v = -1;
            String[] vb = {"usb", "ac", "wireless", "dc", "main"};
            for (String n : vb) {
                long x = readLong("/sys/class/power_supply/" + n + "/voltage_now");
                if (x > 1000000 && x < 30000000) {
                    v = x / 1000;
                    break;
                }
            }
            if (v > 0) put(o, "chargerMv", v);
            long vmax = readLong("/sys/class/power_supply/usb/voltage_max");
            if (vmax > 1000000 && vmax < 30000000) put(o, "chargerMaxMv", vmax / 1000);
            long cmax = readLong("/sys/class/power_supply/usb/current_max");
            if (cmax > 100000) put(o, "chargerMaxMa", cmax / 1000);
        } catch (Throwable ignored) {
        }
        return o.toString();
    }

    // ===================== الأذونات =====================
    private boolean has(String p) {
        return Build.VERSION.SDK_INT < 23 || act.checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED;
    }

    @JavascriptInterface
    public String perms() {
        JSONObject o = new JSONObject();
        put(o, "camera", has(Manifest.permission.CAMERA));
        put(o, "mic", has(Manifest.permission.RECORD_AUDIO));
        put(o, "gps", has(Manifest.permission.ACCESS_FINE_LOCATION));
        put(o, "phone", has(Manifest.permission.READ_PHONE_STATE));
        return o.toString();
    }

    @JavascriptInterface
    public void requestPerms() {
        act.runOnUiThread(new Runnable() {
            public void run() {
                if (Build.VERSION.SDK_INT < 23) return;
                String[] all = {Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO,
                        Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION,
                        Manifest.permission.READ_PHONE_STATE};
                List<String> need = new ArrayList<String>();
                for (String p : all) if (!has(p)) need.add(p);
                if (need.isEmpty()) {
                    onPermResult();
                    return;
                }
                act.requestPermissions(need.toArray(new String[0]), REQ);
            }
        });
    }

    void onPermResult() {
        main.post(new Runnable() {
            public void run() {
                web.evaluateJavascript("window.onPerms&&onPerms()", null);
            }
        });
    }

    // ===================== فتح الإعدادات والروابط =====================
    @JavascriptInterface
    public void openSettings(final String what) {
        act.runOnUiThread(new Runnable() {
            public void run() {
                try {
                    String action;
                    switch (what) {
                        case "overlay": action = Settings.ACTION_MANAGE_OVERLAY_PERMISSION; break;
                        case "battery": action = Intent.ACTION_POWER_USAGE_SUMMARY; break;
                        case "storage": action = Settings.ACTION_INTERNAL_STORAGE_SETTINGS; break;
                        case "update": action = Settings.ACTION_DEVICE_INFO_SETTINGS; break;
                        case "date": action = Settings.ACTION_DATE_SETTINGS; break;
                        case "apn": action = Settings.ACTION_APN_SETTINGS; break;
                        case "access": action = Settings.ACTION_ACCESSIBILITY_SETTINGS; break;
                        case "apps": action = Settings.ACTION_MANAGE_ALL_APPLICATIONS_SETTINGS; break;
                        case "location": action = Settings.ACTION_LOCATION_SOURCE_SETTINGS; break;
                        default: action = Settings.ACTION_SETTINGS;
                    }
                    act.startActivity(new Intent(action));
                } catch (Exception e) {
                    try {
                        act.startActivity(new Intent(Settings.ACTION_SETTINGS));
                    } catch (Exception ignored) {
                    }
                }
            }
        });
    }

    @JavascriptInterface
    public void openUrl(final String url) {
        act.runOnUiThread(new Runnable() {
            public void run() {
                try {
                    act.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
                } catch (Exception ignored) {
                }
            }
        });
    }

    // ===================== قراءة المعلومات (سريعة) =====================
    @JavascriptInterface
    public String info() {
        JSONObject o = new JSONObject();
        try {
            put(o, "device", device());
            put(o, "battery", battery());
            put(o, "storage", storage());
            put(o, "memory", memory());
            put(o, "display", display());
            put(o, "network", network());
            put(o, "security", security());
            put(o, "apps", apps());
            put(o, "sensors", sensors());
            put(o, "features", features());
            put(o, "time", timeInfo());
            put(o, "specs", specs());
            put(o, "google", googleInfo());
            put(o, "wa", waInfo());
        } catch (Throwable ignored) {
        }
        return o.toString();
    }

    private JSONObject device() {
        JSONObject o = new JSONObject();
        put(o, "brand", Build.BRAND);
        put(o, "manufacturer", Build.MANUFACTURER);
        put(o, "model", Build.MODEL);
        put(o, "hardware", Build.HARDWARE);
        put(o, "board", Build.BOARD);
        put(o, "release", Build.VERSION.RELEASE);
        put(o, "sdk", Build.VERSION.SDK_INT);
        put(o, "patch", Build.VERSION.SECURITY_PATCH);
        if (Build.VERSION.SDK_INT >= 31) {
            put(o, "soc", (Build.SOC_MANUFACTURER + " " + Build.SOC_MODEL).trim());
        }
        put(o, "abi", Build.SUPPORTED_ABIS.length > 0 ? Build.SUPPORTED_ABIS[0] : "");
        int cores = Runtime.getRuntime().availableProcessors();
        put(o, "cores", cores);
        put(o, "maxMHz", maxFreqMHz(cores));
        return o;
    }

    private long maxFreqMHz(int cores) {
        long best = 0;
        for (int i = 0; i < cores; i++) {
            try {
                BufferedReader r = new BufferedReader(
                        new FileReader("/sys/devices/system/cpu/cpu" + i + "/cpufreq/cpuinfo_max_freq"));
                String s = r.readLine();
                r.close();
                if (s != null) best = Math.max(best, Long.parseLong(s.trim()) / 1000);
            } catch (Throwable ignored) {
            }
        }
        return best;
    }

    private JSONObject battery() {
        JSONObject o = new JSONObject();
        try {
            Intent i = act.registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
            if (i == null) return o;
            int lv = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
            int sc = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
            int pct = (lv >= 0 && sc > 0) ? Math.round(lv * 100f / sc) : -1;
            int status = i.getIntExtra(BatteryManager.EXTRA_STATUS, 1);
            put(o, "level", pct);
            put(o, "status", status);
            put(o, "charging", status == BatteryManager.BATTERY_STATUS_CHARGING
                    || status == BatteryManager.BATTERY_STATUS_FULL);
            put(o, "health", i.getIntExtra(BatteryManager.EXTRA_HEALTH, 1));
            put(o, "plugged", i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0));
            put(o, "temp", i.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) / 10.0);
            put(o, "voltage", i.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0));
            put(o, "tech", i.getStringExtra(BatteryManager.EXTRA_TECHNOLOGY));
            put(o, "cycles", i.getIntExtra("android.os.extra.CYCLE_COUNT", -1));

            BatteryManager bm = (BatteryManager) act.getSystemService(Context.BATTERY_SERVICE);
            int cap = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY);
            long cc = bm.getLongProperty(BatteryManager.BATTERY_PROPERTY_CHARGE_COUNTER);
            int cur = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW);
            if (cur != Integer.MIN_VALUE && cur != 0) put(o, "currentMa", Math.abs(cur) / 1000);

            double design = 0;
            try {
                Class<?> c = Class.forName("com.android.internal.os.PowerProfile");
                Object pp = c.getConstructor(Context.class).newInstance(act);
                design = ((Number) c.getMethod("getBatteryCapacity").invoke(pp)).doubleValue();
            } catch (Throwable ignored) {
            }
            if (design > 500) put(o, "designMah", Math.round(design));
            if (cap >= 20 && cc > 0 && cc != Long.MIN_VALUE) {
                double est = cc / 1000.0 / (cap / 100.0);
                put(o, "estMah", Math.round(est));
                if (design > 500) {
                    double ratio = est / design;
                    if (ratio > 0.3 && ratio < 1.3) put(o, "healthPct", Math.min(100, Math.round(ratio * 100)));
                }
            }
        } catch (Throwable ignored) {
        }
        try {
            BatteryManager bm2 = (BatteryManager) act.getSystemService(Context.BATTERY_SERVICE);
            int life = -1;
            String src = "";
            if (Build.VERSION.SDK_INT >= 34) {
                int soh = bm2.getIntProperty(10); // BATTERY_PROPERTY_STATE_OF_HEALTH
                if (soh > 0 && soh <= 100) {
                    life = soh;
                    src = "النظام";
                }
            }
            long full = readLong("/sys/class/power_supply/battery/charge_full");
            long des = readLong("/sys/class/power_supply/battery/charge_full_design");
            if (full > 0 && des > 0) {
                int pct = (int) Math.round(full * 100.0 / des);
                if (pct > 30 && pct <= 110) {
                    put(o, "sysPct", Math.min(100, pct));
                    if (life < 0) {
                        life = Math.min(100, pct);
                        src = "قراءة السعة";
                    }
                }
            }
            if (life < 0 && o.has("healthPct")) {
                life = o.optInt("healthPct");
                src = "حساب السعة";
            }
            int cyc = o.optInt("cycles", -1);
            if (cyc <= 0) {
                long cc2 = readLong("/sys/class/power_supply/battery/cycle_count");
                if (cc2 > 0) {
                    cyc = (int) cc2;
                    put(o, "cycles", cyc);
                }
            }
            if (life < 0 && cyc > 0) {
                life = (int) Math.max(40, Math.round(100 - cyc * 0.04));
                src = "تقدير من دورات الشحن";
            }
            if (life > 0) {
                put(o, "lifePct", life);
                put(o, "lifeSrc", src);
            }
        } catch (Throwable ignored) {
        }
        return o;
    }

    private static long readLong(String path) {
        try {
            BufferedReader r = new BufferedReader(new FileReader(path));
            String s = r.readLine();
            r.close();
            return s == null ? -1 : Long.parseLong(s.trim());
        } catch (Throwable t) {
            return -1;
        }
    }

    private static String prop(String k) {
        try {
            Class<?> c = Class.forName("android.os.SystemProperties");
            String v = (String) c.getMethod("get", String.class, String.class).invoke(null, k, "");
            if (v != null) return v.trim();
        } catch (Throwable ignored) {
        }
        try {
            Process p = Runtime.getRuntime().exec(new String[]{"getprop", k});
            BufferedReader r = new BufferedReader(new java.io.InputStreamReader(p.getInputStream()));
            String s = r.readLine();
            r.close();
            return s == null ? "" : s.trim();
        } catch (Throwable t) {
            return "";
        }
    }

    private static String firstProp(String... keys) {
        for (String k : keys) {
            String v = prop(k);
            if (v.length() > 0 && !v.equalsIgnoreCase("unknown")) return v;
        }
        return "";
    }

    private String cpuHardware() {
        try {
            BufferedReader r = new BufferedReader(new FileReader("/proc/cpuinfo"));
            String l;
            String res = "";
            while ((l = r.readLine()) != null) {
                if (l.startsWith("Hardware")) {
                    int i = l.indexOf(':');
                    if (i > 0) res = l.substring(i + 1).trim();
                }
            }
            r.close();
            return res;
        } catch (Throwable t) {
            return "";
        }
    }

    /** مواصفات كاملة للجهاز: الاسم التجاري، المعالج، الشاشة، الكاميرات، المستشعرات... */
    private JSONObject specs() {
        JSONObject o = new JSONObject();
        try {
            put(o, "marketName", firstProp("ro.product.marketname", "ro.product.vendor.marketname",
                    "ro.product.odm.marketname", "ro.product.system.marketname", "ro.vendor.oplus.market.name",
                    "ro.oppo.market.name", "ro.vivo.market.name", "ro.config.marketing_name",
                    "ro.product.vendor.model_name"));
            put(o, "codename", Build.DEVICE);
            put(o, "product", Build.PRODUCT);
            put(o, "buildId", Build.DISPLAY);
            put(o, "kernel", System.getProperty("os.version"));
            put(o, "bootloader", Build.BOOTLOADER);
            put(o, "fingerprint", Build.FINGERPRINT);
            put(o, "platform", firstProp("ro.board.platform", "ro.mediatek.platform"));
            put(o, "cpuHw", cpuHardware());
            put(o, "socMan", firstProp("ro.soc.manufacturer", "ro.hardware.chipname"));
            put(o, "socModel", firstProp("ro.soc.model"));
            put(o, "verifiedBoot", prop("ro.boot.verifiedbootstate"));
            put(o, "flashLocked", prop("ro.boot.flash.locked"));
            put(o, "locale", Locale.getDefault().toString());
            JSONArray abis = new JSONArray();
            for (String a : Build.SUPPORTED_ABIS) abis.put(a);
            put(o, "abis", abis);

            int cores = Runtime.getRuntime().availableProcessors();
            JSONArray freqs = new JSONArray();
            for (int i = 0; i < cores; i++) {
                long f = readLong("/sys/devices/system/cpu/cpu" + i + "/cpufreq/cpuinfo_max_freq");
                freqs.put(f > 0 ? f / 1000 : 0);
            }
            put(o, "coreMax", freqs);
        } catch (Throwable ignored) {
        }
        try {
            DisplayMetrics dm = new DisplayMetrics();
            Display d = act.getWindowManager().getDefaultDisplay();
            d.getRealMetrics(dm);
            double inch = Math.sqrt(Math.pow(dm.widthPixels / dm.xdpi, 2) + Math.pow(dm.heightPixels / dm.ydpi, 2));
            put(o, "inches", Math.round(inch * 10) / 10.0);
            JSONArray hz = new JSONArray();
            java.util.TreeSet<Integer> set = new java.util.TreeSet<Integer>();
            if (Build.VERSION.SDK_INT >= 23) {
                for (Display.Mode m : d.getSupportedModes()) set.add(Math.round(m.getRefreshRate()));
            }
            for (Integer h : set) hz.put(h);
            put(o, "hzModes", hz);
            put(o, "hdr", Build.VERSION.SDK_INT >= 26 && d.isHdr());
        } catch (Throwable ignored) {
        }
        try {
            CameraManager cm = (CameraManager) act.getSystemService(Context.CAMERA_SERVICE);
            JSONArray cams = new JSONArray();
            for (String id : cm.getCameraIdList()) {
                CameraCharacteristics cc = cm.getCameraCharacteristics(id);
                JSONObject c = new JSONObject();
                Integer facing = cc.get(CameraCharacteristics.LENS_FACING);
                put(c, "facing", facing == null ? "other" : facing == CameraCharacteristics.LENS_FACING_FRONT
                        ? "front" : facing == CameraCharacteristics.LENS_FACING_BACK ? "back" : "other");
                android.util.Size sz = cc.get(CameraCharacteristics.SENSOR_INFO_PIXEL_ARRAY_SIZE);
                if (sz != null) put(c, "mp", Math.round(sz.getWidth() * (double) sz.getHeight() / 1e6));
                float[] fl = cc.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS);
                if (fl != null && fl.length > 0) put(c, "focal", Math.round(fl[0] * 10) / 10.0);
                cams.put(c);
            }
            put(o, "cams", cams);
        } catch (Throwable ignored) {
        }
        try {
            PackageManager pm = act.getPackageManager();
            put(o, "usbHost", pm.hasSystemFeature("android.hardware.usb.host"));
            put(o, "ble", pm.hasSystemFeature("android.hardware.bluetooth_le"));
            put(o, "ir", pm.hasSystemFeature("android.hardware.consumer_ir"));
            put(o, "wifiDirect", pm.hasSystemFeature("android.hardware.wifi.direct"));
            put(o, "face", pm.hasSystemFeature("android.hardware.biometrics.face"));
        } catch (Throwable ignored) {
        }
        try {
            WifiManager wm = (WifiManager) act.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            StringBuilder w = new StringBuilder("Wi‑Fi");
            if (Build.VERSION.SDK_INT >= 30) {
                if (wm.isWifiStandardSupported(android.net.wifi.ScanResult.WIFI_STANDARD_11AX)) w.append(" 6");
                else if (wm.isWifiStandardSupported(android.net.wifi.ScanResult.WIFI_STANDARD_11AC)) w.append(" 5");
                else if (wm.isWifiStandardSupported(android.net.wifi.ScanResult.WIFI_STANDARD_11N)) w.append(" 4");
                if (Build.VERSION.SDK_INT >= 33 && wm.isWifiStandardSupported(8)) w.append(" (و Wi‑Fi 7)");
                if (wm.is6GHzBandSupported()) w.append(" · 6GHz");
            }
            if (wm.is5GHzBandSupported()) w.append(" · 5GHz");
            put(o, "wifiStd", w.toString());
        } catch (Throwable ignored) {
        }
        try {
            TelephonyManager tm = (TelephonyManager) act.getSystemService(Context.TELEPHONY_SERVICE);
            if (Build.VERSION.SDK_INT >= 23) put(o, "simSlots", tm.getPhoneCount());
        } catch (Throwable ignored) {
        }
        try {
            MediaDrm drm = new MediaDrm(new UUID(0xEDEF8BA979D64ACEL, 0xA3C827DCD51D21EDL));
            put(o, "widevine", drm.getPropertyString("securityLevel"));
            drm.release();
        } catch (Throwable ignored) {
        }
        try {
            SensorManager sm = (SensorManager) act.getSystemService(Context.SENSOR_SERVICE);
            JSONArray names = new JSONArray();
            for (Sensor se : sm.getSensorList(Sensor.TYPE_ALL)) {
                if (names.length() >= 30) break;
                String nm = se.getName();
                if (nm != null && !names.toString().contains(JSONObject.quote(nm))) names.put(nm);
            }
            put(o, "sensorNames", names);
        } catch (Throwable ignored) {
        }
        return o;
    }

    private JSONObject storage() {
        JSONObject o = new JSONObject();
        try {
            StatFs sf = new StatFs(Environment.getDataDirectory().getPath());
            put(o, "total", sf.getTotalBytes());
            put(o, "free", sf.getAvailableBytes());
        } catch (Throwable ignored) {
        }
        return o;
    }

    private JSONObject memory() {
        JSONObject o = new JSONObject();
        try {
            ActivityManager am = (ActivityManager) act.getSystemService(Context.ACTIVITY_SERVICE);
            ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
            am.getMemoryInfo(mi);
            put(o, "total", mi.totalMem);
            put(o, "avail", mi.availMem);
            put(o, "low", mi.lowMemory);
        } catch (Throwable ignored) {
        }
        return o;
    }

    private JSONObject display() {
        JSONObject o = new JSONObject();
        try {
            DisplayMetrics dm = new DisplayMetrics();
            Display d = act.getWindowManager().getDefaultDisplay();
            d.getRealMetrics(dm);
            put(o, "w", dm.widthPixels);
            put(o, "h", dm.heightPixels);
            put(o, "dpi", dm.densityDpi);
            put(o, "hz", Math.round(d.getRefreshRate()));
        } catch (Throwable ignored) {
        }
        return o;
    }

    private static String netTypeName(int t) {
        switch (t) {
            case 20: return "5G";
            case 13: return "4G LTE";
            case 15: case 10: case 9: case 8: case 3: return "3G";
            case 1: case 2: case 4: return "2G";
            default: return "";
        }
    }

    private JSONObject network() {
        JSONObject o = new JSONObject();
        try {
            ConnectivityManager cm = (ConnectivityManager) act.getSystemService(Context.CONNECTIVITY_SERVICE);
            Network n = cm.getActiveNetwork();
            NetworkCapabilities nc = n == null ? null : cm.getNetworkCapabilities(n);
            put(o, "connected", nc != null);
            put(o, "wifi", nc != null && nc.hasTransport(NetworkCapabilities.TRANSPORT_WIFI));
            put(o, "cell", nc != null && nc.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR));
            put(o, "validated", nc != null && nc.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED));
        } catch (Throwable ignored) {
        }
        try {
            ConnectivityManager cm2 = (ConnectivityManager) act.getSystemService(Context.CONNECTIVITY_SERVICE);
            if (Build.VERSION.SDK_INT >= 24) {
                int rb = cm2.getRestrictBackgroundStatus(); // 1 متوقف، 2 مفعّل والتطبيق مستثنى، 3 مفعّل
                put(o, "dataSaver", rb);
            }
            put(o, "metered", cm2.isActiveNetworkMetered());
        } catch (Throwable ignored) {
        }
        try {
            WifiManager wm = (WifiManager) act.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            put(o, "wifiOn", wm.isWifiEnabled());
            int rssi = wm.getConnectionInfo().getRssi();
            if (rssi > -127 && rssi < 0) put(o, "wifiLevel", WifiManager.calculateSignalLevel(rssi, 5));
        } catch (Throwable ignored) {
        }
        try {
            TelephonyManager tm = (TelephonyManager) act.getSystemService(Context.TELEPHONY_SERVICE);
            put(o, "sim", tm.getSimState()); // 5 = جاهزة، 1 = لا توجد شريحة
            put(o, "operator", tm.getNetworkOperatorName());
            if (Build.VERSION.SDK_INT >= 24 && has(Manifest.permission.READ_PHONE_STATE)) {
                put(o, "netType", netTypeName(tm.getDataNetworkType()));
            }
        } catch (Throwable ignored) {
        }
        return o;
    }

    private JSONObject security() {
        JSONObject o = new JSONObject();
        boolean root = false;
        String[] paths = {"/system/bin/su", "/system/xbin/su", "/sbin/su", "/su/bin/su",
                "/system/app/Superuser.apk", "/data/local/xbin/su", "/data/local/bin/su"};
        for (String p : paths) {
            try {
                if (new File(p).exists()) root = true;
            } catch (Throwable ignored) {
            }
        }
        String tags = Build.TAGS;
        if (tags != null && tags.contains("test-keys")) root = true;
        put(o, "root", root);
        try {
            put(o, "adb", Settings.Global.getInt(act.getContentResolver(), Settings.Global.ADB_ENABLED, 0) == 1);
            put(o, "dev", Settings.Global.getInt(act.getContentResolver(),
                    Settings.Global.DEVELOPMENT_SETTINGS_ENABLED, 0) == 1);
        } catch (Throwable ignored) {
        }
        try {
            KeyguardManager km = (KeyguardManager) act.getSystemService(Context.KEYGUARD_SERVICE);
            put(o, "lock", km.isDeviceSecure());
        } catch (Throwable ignored) {
        }
        try {
            DevicePolicyManager dpm = (DevicePolicyManager) act.getSystemService(Context.DEVICE_POLICY_SERVICE);
            int e = dpm.getStorageEncryptionStatus();
            put(o, "encrypted", e == DevicePolicyManager.ENCRYPTION_STATUS_ACTIVE
                    || e == DevicePolicyManager.ENCRYPTION_STATUS_ACTIVE_PER_USER
                    || e == DevicePolicyManager.ENCRYPTION_STATUS_ACTIVE_DEFAULT_KEY);
        } catch (Throwable ignored) {
        }
        return o;
    }

    private static String label(PackageManager pm, ApplicationInfo ai) {
        try {
            return pm.getApplicationLabel(ai).toString();
        } catch (Throwable t) {
            return ai.packageName;
        }
    }

    private JSONObject apps() {
        JSONObject o = new JSONObject();
        try {
            PackageManager pm = act.getPackageManager();
            AppOpsManager ops = (AppOpsManager) act.getSystemService(Context.APP_OPS_SERVICE);
            List<PackageInfo> all = pm.getInstalledPackages(0);
            List<PackageInfo> mine = new ArrayList<PackageInfo>();
            JSONArray overlay = new JSONArray();
            for (PackageInfo p : all) {
                ApplicationInfo ai = p.applicationInfo;
                if (ai == null) continue;
                boolean sys = (ai.flags & (ApplicationInfo.FLAG_SYSTEM | ApplicationInfo.FLAG_UPDATED_SYSTEM_APP)) != 0;
                if (sys || p.packageName.equals(act.getPackageName())) continue;
                mine.add(p);
                try {
                    if (overlay.length() < 15 && ops.checkOpNoThrow("android:system_alert_window", ai.uid,
                            p.packageName) == AppOpsManager.MODE_ALLOWED) {
                        overlay.put(label(pm, ai));
                    }
                } catch (Throwable ignored) {
                }
            }
            put(o, "total", all.size());
            put(o, "user", mine.size());
            put(o, "overlay", overlay);

            Collections.sort(mine, new Comparator<PackageInfo>() {
                public int compare(PackageInfo a, PackageInfo b) {
                    return Long.compare(b.firstInstallTime, a.firstInstallTime);
                }
            });
            JSONArray recent = new JSONArray();
            long now = System.currentTimeMillis();
            for (int i = 0; i < mine.size() && i < 6; i++) {
                PackageInfo p = mine.get(i);
                JSONObject r = new JSONObject();
                put(r, "name", label(pm, p.applicationInfo));
                put(r, "days", (now - p.firstInstallTime) / 86400000L);
                recent.put(r);
            }
            put(o, "recent", recent);

            JSONArray acc = new JSONArray();
            String en = Settings.Secure.getString(act.getContentResolver(),
                    Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
            if (en != null && en.length() > 0) {
                for (String comp : en.split(":")) {
                    int s = comp.indexOf('/');
                    String pkg = s > 0 ? comp.substring(0, s) : comp;
                    try {
                        ApplicationInfo ai = pm.getApplicationInfo(pkg, 0);
                        boolean sys = (ai.flags & (ApplicationInfo.FLAG_SYSTEM | ApplicationInfo.FLAG_UPDATED_SYSTEM_APP)) != 0;
                        if (!sys && acc.length() < 10) acc.put(label(pm, ai));
                    } catch (Throwable ignored) {
                    }
                }
            }
            put(o, "access", acc);
        } catch (Throwable ignored) {
        }
        return o;
    }

    private JSONObject sensors() {
        JSONObject o = new JSONObject();
        try {
            SensorManager sm = (SensorManager) act.getSystemService(Context.SENSOR_SERVICE);
            put(o, "count", sm.getSensorList(Sensor.TYPE_ALL).size());
            put(o, "accel", sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER) != null);
            put(o, "gyro", sm.getDefaultSensor(Sensor.TYPE_GYROSCOPE) != null);
            put(o, "mag", sm.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD) != null);
            put(o, "light", sm.getDefaultSensor(Sensor.TYPE_LIGHT) != null);
            put(o, "prox", sm.getDefaultSensor(Sensor.TYPE_PROXIMITY) != null);
            put(o, "baro", sm.getDefaultSensor(Sensor.TYPE_PRESSURE) != null);
        } catch (Throwable ignored) {
        }
        return o;
    }

    private JSONObject features() {
        JSONObject o = new JSONObject();
        try {
            PackageManager pm = act.getPackageManager();
            put(o, "fingerprint", pm.hasSystemFeature("android.hardware.fingerprint"));
            put(o, "nfc", pm.hasSystemFeature("android.hardware.nfc"));
            put(o, "bluetooth", pm.hasSystemFeature("android.hardware.bluetooth"));
            put(o, "gps", pm.hasSystemFeature("android.hardware.location.gps"));
            put(o, "flash", pm.hasSystemFeature("android.hardware.camera.flash"));
            put(o, "telephony", pm.hasSystemFeature("android.hardware.telephony"));
            put(o, "camFront", pm.hasSystemFeature("android.hardware.camera.front"));
            put(o, "camBack", pm.hasSystemFeature("android.hardware.camera"));
        } catch (Throwable ignored) {
        }
        return o;
    }

    private JSONObject timeInfo() {
        JSONObject o = new JSONObject();
        try {
            put(o, "autoTime", Settings.Global.getInt(act.getContentResolver(), Settings.Global.AUTO_TIME, 0) == 1);
            put(o, "autoZone", Settings.Global.getInt(act.getContentResolver(), Settings.Global.AUTO_TIME_ZONE, 0) == 1);
            put(o, "zone", java.util.TimeZone.getDefault().getID());
        } catch (Throwable ignored) {
        }
        return o;
    }

    // ===================== اختبارات القطع (غير متزامنة) =====================
    @JavascriptInterface
    public void test(final String name) {
        new Thread(new Runnable() {
            public void run() {
                JSONObject r = new JSONObject();
                try {
                    switch (name) {
                        case "camera": r = testCamera(); break;
                        case "flash": r = testFlash(); break;
                        case "mic": r = testMic(); break;
                        case "gps": r = testGps(); break;
                        case "vibrate": r = testVibrate(); break;
                        case "speaker": r = testSpeaker(); break;
                        case "sensors": r = testSensors(); break;
                        default: put(r, "status", "unknown");
                    }
                } catch (Throwable t) {
                    put(r, "status", "error");
                    put(r, "error", String.valueOf(t));
                }
                deliver(name, r);
            }
        }).start();
    }

    private void deliver(String name, JSONObject r) {
        final String js = "window.onNativeResult&&onNativeResult(" + JSONObject.quote(name) + "," + r.toString() + ")";
        main.post(new Runnable() {
            public void run() {
                web.evaluateJavascript(js, null);
            }
        });
    }

    private JSONObject testCamera() throws Exception {
        JSONObject r = new JSONObject();
        if (!has(Manifest.permission.CAMERA)) {
            put(r, "status", "noperm");
            return r;
        }
        CameraManager cm = (CameraManager) act.getSystemService(Context.CAMERA_SERVICE);
        HandlerThread ht = new HandlerThread("camtest");
        ht.start();
        Handler h = new Handler(ht.getLooper());
        JSONArray arr = new JSONArray();
        try {
            for (String id : cm.getCameraIdList()) {
                final boolean[] ok = {false};
                final CountDownLatch latch = new CountDownLatch(1);
                JSONObject item = new JSONObject();
                put(item, "id", id);
                Integer facing = cm.getCameraCharacteristics(id).get(CameraCharacteristics.LENS_FACING);
                put(item, "facing", facing == null ? "other"
                        : facing == CameraCharacteristics.LENS_FACING_FRONT ? "front"
                        : facing == CameraCharacteristics.LENS_FACING_BACK ? "back" : "other");
                try {
                    cm.openCamera(id, new CameraDevice.StateCallback() {
                        public void onOpened(CameraDevice d) {
                            ok[0] = true;
                            d.close();
                            latch.countDown();
                        }

                        public void onDisconnected(CameraDevice d) {
                            d.close();
                            latch.countDown();
                        }

                        public void onError(CameraDevice d, int e) {
                            d.close();
                            latch.countDown();
                        }
                    }, h);
                    latch.await(6, TimeUnit.SECONDS);
                } catch (Throwable t) {
                    put(item, "err", String.valueOf(t));
                }
                put(item, "ok", ok[0]);
                arr.put(item);
            }
        } finally {
            ht.quitSafely();
        }
        put(r, "status", "done");
        put(r, "cams", arr);
        return r;
    }

    private JSONObject testFlash() throws Exception {
        JSONObject r = new JSONObject();
        CameraManager cm = (CameraManager) act.getSystemService(Context.CAMERA_SERVICE);
        String torchId = null;
        for (String id : cm.getCameraIdList()) {
            Boolean f = cm.getCameraCharacteristics(id).get(CameraCharacteristics.FLASH_INFO_AVAILABLE);
            if (f != null && f) {
                torchId = id;
                break;
            }
        }
        if (torchId == null) {
            put(r, "status", "noflash");
            return r;
        }
        cm.setTorchMode(torchId, true);
        try {
            Thread.sleep(1500);
        } finally {
            cm.setTorchMode(torchId, false);
        }
        put(r, "status", "done");
        return r;
    }

    private JSONObject testMic() {
        JSONObject r = new JSONObject();
        if (!has(Manifest.permission.RECORD_AUDIO)) {
            put(r, "status", "noperm");
            return r;
        }
        int rate = 44100;
        int min = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
        if (min <= 0) {
            put(r, "status", "error");
            return r;
        }
        AudioRecord ar = new AudioRecord(MediaRecorder.AudioSource.MIC, rate, AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT, min * 2);
        if (ar.getState() != AudioRecord.STATE_INITIALIZED) {
            ar.release();
            put(r, "status", "error");
            return r;
        }
        short[] buf = new short[min];
        int peak = 0;
        long end = System.currentTimeMillis() + 3000;
        ar.startRecording();
        try {
            while (System.currentTimeMillis() < end) {
                int n = ar.read(buf, 0, buf.length);
                for (int i = 0; i < n; i++) peak = Math.max(peak, Math.abs((int) buf[i]));
            }
        } finally {
            ar.stop();
            ar.release();
        }
        put(r, "status", "done");
        put(r, "peak", peak); // لا يُخزَّن أي صوت، فقط أعلى مستوى
        return r;
    }

    private JSONObject testGps() throws Exception {
        JSONObject r = new JSONObject();
        if (!has(Manifest.permission.ACCESS_FINE_LOCATION)) {
            put(r, "status", "noperm");
            return r;
        }
        final LocationManager lm = (LocationManager) act.getSystemService(Context.LOCATION_SERVICE);
        if (!lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
            put(r, "status", "off");
            return r;
        }
        HandlerThread ht = new HandlerThread("gpstest");
        ht.start();
        final CountDownLatch latch = new CountDownLatch(1);
        final float[] acc = {-1f};
        LocationListener ll = new LocationListener() {
            public void onLocationChanged(Location l) {
                acc[0] = l.getAccuracy();
                latch.countDown();
            }

            public void onStatusChanged(String p, int s, Bundle b) {
            }

            public void onProviderEnabled(String p) {
            }

            public void onProviderDisabled(String p) {
            }
        };
        long t0 = System.currentTimeMillis();
        boolean got;
        try {
            lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0L, 0f, ll, ht.getLooper());
            got = latch.await(25, TimeUnit.SECONDS);
        } finally {
            lm.removeUpdates(ll);
            ht.quitSafely();
        }
        put(r, "status", got ? "done" : "timeout"); // لا نرسل الإحداثيات أبداً، فقط الدقة والزمن
        if (got) {
            put(r, "sec", (System.currentTimeMillis() - t0) / 1000);
            put(r, "acc", Math.round(acc[0]));
        }
        return r;
    }

    private JSONObject testVibrate() {
        JSONObject r = new JSONObject();
        Vibrator v = (Vibrator) act.getSystemService(Context.VIBRATOR_SERVICE);
        if (v == null || !v.hasVibrator()) {
            put(r, "status", "none");
            return r;
        }
        if (Build.VERSION.SDK_INT >= 26) {
            v.vibrate(VibrationEffect.createOneShot(800, VibrationEffect.DEFAULT_AMPLITUDE));
        } else {
            v.vibrate(800);
        }
        put(r, "status", "done");
        return r;
    }

    private JSONObject testSpeaker() throws Exception {
        JSONObject r = new JSONObject();
        AudioManager am = (AudioManager) act.getSystemService(Context.AUDIO_SERVICE);
        int max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
        int cur = am.getStreamVolume(AudioManager.STREAM_MUSIC);
        put(r, "vol", max > 0 ? Math.round(cur * 100f / max) : 0);
        ToneGenerator tg = new ToneGenerator(AudioManager.STREAM_MUSIC, 100);
        try {
            tg.startTone(ToneGenerator.TONE_PROP_BEEP2, 1200);
            Thread.sleep(1500);
        } finally {
            tg.release();
        }
        put(r, "status", "done");
        return r;
    }

    private JSONObject testSensors() throws Exception {
        JSONObject r = new JSONObject();
        final SensorManager sm = (SensorManager) act.getSystemService(Context.SENSOR_SERVICE);
        final int[] types = {Sensor.TYPE_ACCELEROMETER, Sensor.TYPE_GYROSCOPE, Sensor.TYPE_MAGNETIC_FIELD,
                Sensor.TYPE_LIGHT, Sensor.TYPE_PROXIMITY};
        final String[] names = {"accel", "gyro", "mag", "light", "prox"};
        final float[][] last = new float[types.length][];
        HandlerThread ht = new HandlerThread("sensortest");
        ht.start();
        Handler h = new Handler(ht.getLooper());
        SensorEventListener l = new SensorEventListener() {
            public void onSensorChanged(SensorEvent e) {
                for (int i = 0; i < types.length; i++) {
                    if (e.sensor.getType() == types[i]) last[i] = e.values.clone();
                }
            }

            public void onAccuracyChanged(Sensor s, int a) {
            }
        };
        try {
            for (int t : types) {
                Sensor s = sm.getDefaultSensor(t);
                if (s != null) sm.registerListener(l, s, SensorManager.SENSOR_DELAY_NORMAL, h);
            }
            Thread.sleep(2000);
        } finally {
            sm.unregisterListener(l);
            ht.quitSafely();
        }
        for (int i = 0; i < types.length; i++) {
            if (last[i] != null) {
                JSONArray a = new JSONArray();
                for (float f : last[i]) a.put(Double.valueOf(Math.round(f * 100.0) / 100.0));
                put(r, names[i], a);
            } else if (sm.getDefaultSensor(types[i]) == null) {
                put(r, names[i], "none");
            }
        }
        put(r, "status", "done");
        return r;
    }
}
